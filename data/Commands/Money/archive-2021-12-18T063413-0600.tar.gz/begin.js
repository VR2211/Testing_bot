module.exports = {
	name: "begin",
    code: `$setGlobalUserVar[acc;true]
  $setGlobalUserVar[Cash;$sum[$getGlobalUserVar[Cash];500]]
  $description[1;Thank you for makeing an acc $username. I have add 500 to your cash to get you stated.]
  $onlyIf[$getGlobalUserVar[acc]==false;You have an acc]`
}
