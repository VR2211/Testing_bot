module.exports = ({
 name: "cupdate",
 code: `$updateCommands
 $description[1;Commamds have be Update]
$onlyForIDs[745691705390399590;822525798065373265;only my dev can do this]
 `})