module.exports = {
    name: "eval",
    code: `
$eval[\`\`\`$message\`\`\`]
$onlyForIDs[745691705390399590;This can only be used by the developer]`
}

