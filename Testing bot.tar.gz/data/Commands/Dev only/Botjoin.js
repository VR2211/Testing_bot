module.exports = {
    type: "guildJoin",
    channel: "917755765475930132",
    code: `
    $title[1;New server joined]
    $description[1;I have Joined $serverName]`
}


