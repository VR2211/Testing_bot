module.exports = {
    type: "guildLeave",
    channel: "917755765475930132",
    code: `
    $title[1;Server left]
    $description[1;I have left $serverName]`
}