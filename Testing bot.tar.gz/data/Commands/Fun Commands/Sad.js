module.exports = ({
    name: "sad",
    code: `$title[1;$username is sad can some please hug them]
    $image[1;$jsonRequest[https://nekos.best/api/v1/cry; url;An error occurred]]
$color[1;RANDOM]
$footer[1;Powered by nekos.best api]`
   })