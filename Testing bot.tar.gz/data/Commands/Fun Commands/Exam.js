module.exports = {
    name: "Exam",
    code: `
    $title[1;Exam written]
    $description[1;Dear $username You wrote you exam today and got $random[0;100]/100]
    $footer[1;Requsted by $username]
    $color[1;RANDOM]`
        }