module.exports = ({
    name: "bored",
    code: `$title[1;$username is bored]
    $image[1;$jsonRequest[https://nekos.best/api/v1/bored; url;An error occurred]]
$color[1;RANDOM]
$footer[1;Powered by nekos.best api]`
   })