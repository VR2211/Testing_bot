module.exports = ({
    name: "sleep",
    code: `$title[1;$username is sleeping]
    $image[1;$jsonRequest[https://nekos.best/api/v1/sleep; url;An error occurred]]
$color[1;RANDOM]
$footer[1;Powered by nekos.best api]`
   })