module.exports = ({
    name: "slap",
    code: `$title[1;$username slap $username[$mentioned[1]] that must have hurt]
    $image[1;$jsonRequest[https://nekos.best/api/v1/slap; url;An error occurred]]
$color[1;RANDOM]
$footer[1;Powered by nekos.best api]
$argsCheck[1;Mention the person you want to slap]`
   })