module.exports = ({
    name: "blush",
    code: `$title[1;$username is blushing]
    $image[1;$jsonRequest[https://nekos.best/api/v1/blush; url;An error occurred]]
$color[1;RANDOM]
$footer[1;Powered by nekos.best api]`
   })