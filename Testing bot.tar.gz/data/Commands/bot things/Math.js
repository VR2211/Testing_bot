module.exports = {
	 name: "Math",
	 code: `
	 $title[1;Math sum]
	$description[1;
	**Input**	
		\`\`\` $message \`\`\`

		**Output**
	\`\`\` $math[$message] \`\`\`] `
	}