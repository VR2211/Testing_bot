module.exports = {
    name: 'r-bug-eg',
    code: `
    $title[1;Report Bug Exmaple]
    $description[1;How to Use Report Bug
    
    So do \`$getServerVar[prefix]r-bug and you message\`

    Exmpale

\`$getServerVar[prefix]r-bug The Say command is not working\`]
$color[1;RANDOM]
$footer[1;Requested by $username]`
    }