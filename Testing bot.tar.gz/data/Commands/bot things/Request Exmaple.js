module.exports = {
    name: 'request-eg',
    code: `
    $title[1;Request Exmaple]
    $description[1;How to Use Requestz
    
    So do \`$getServerVar[prefix]request and you message\`

    Exmpale

\`$getServerVar[prefix]request please make a weekly command\`]
$color[1;RANDOM]
$footer[1;Requested by $username]`
    }