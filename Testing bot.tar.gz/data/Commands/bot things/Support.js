module.exports = ({
    name: "Support",
    code: `
    $title[1;Support]
    $description[1;**Need help join the Support server**
    Support server: [Support server\\](https://discord.gg/GkhuRTMXm5)
    $color[1;RANDOM]`
})