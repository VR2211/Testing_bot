module.exports = {
type:"interaction",
prototype: "slash",
name: "prefix", 
 code: `$interactionReply[;{newEmbed: {title:Prefix}{description:My Gobal Prefix is a!
And The Server Prefix is $getServerVar[prefix]

To get help do a!help or do $getServerVar[prefix]}};;;;no]`
 }