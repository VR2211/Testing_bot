module.exports = {
type:"interaction",
prototype: "slash",
name: "future", 
 code: `$interactionReply[; {newEmbed: {title:Future Updates}
{description: 
Going to added a User-info Command
Going to update Server info Command
Update Use Commands
Fix all bugs

}};;;;no]`
}
