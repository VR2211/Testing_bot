module.exports = {
type:"interaction",
prototype: "slash",
name: "links", 
 code: `$interactionReply[;{newEmbed: {title:Bot links}
{description:Soon to come}};;;;no]`}