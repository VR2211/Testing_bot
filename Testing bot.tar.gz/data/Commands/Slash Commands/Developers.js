module.exports = {
type:"interaction",
prototype: "slash",
name: "developers", 
 code: `$interactionReply[;{newEmbed:
{description:

Main Developer= $usertag[$botownerid]

Bot Profile Developer= $usertag[$botownerid]

Bot Name Developer= $usertag[$botownerid]}
{color:RANDOM}};;;;no]`}